package com.meenu.meenumart.dao;

import com.meenu.meenumart.model.Review;
import java.sql.SQLException;
import java.util.List;

public interface ReviewDAO {
    List<Review> findByProduct(Long productId) throws SQLException;
    Review save(Review review) throws SQLException;
}
