package com.meenu.meenumart.dao;

import com.meenu.meenumart.model.User;
import java.sql.SQLException;
import java.util.Optional;

public interface UserDAO {
    Optional<User> findByEmail(String email) throws SQLException;
    User save(User user) throws SQLException;
}
