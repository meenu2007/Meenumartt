-- Seed data placeholder.
-- Do NOT hardcode bcrypt hashes here by guessing — they must be generated with jBCrypt.
-- Run com.meenu.meenumart.util.HashGenerator (has a main method) locally, e.g. from
-- your IDE, passing the plain password as the program argument. Copy its printed hash
-- into the INSERT statements below, one per seed user.

-- INSERT INTO users (name, email, password_hash, role) VALUES
--     ('Admin', 'admin@meenumart.com', '<paste generated hash here>', 'ADMIN'),
--     ('Sample Seller', 'seller@meenumart.com', '<paste generated hash here>', 'SELLER'),
--     ('Sample Buyer', 'buyer@meenumart.com', '<paste generated hash here>', 'BUYER');
